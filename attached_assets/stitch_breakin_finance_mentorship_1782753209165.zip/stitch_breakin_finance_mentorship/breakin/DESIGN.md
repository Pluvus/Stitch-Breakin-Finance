---
name: BreakIn
colors:
  surface: '#f7fafc'
  surface-dim: '#d7dadc'
  surface-bright: '#f7fafc'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f4f6'
  surface-container: '#ebeef0'
  surface-container-high: '#e5e9eb'
  surface-container-highest: '#e0e3e5'
  on-surface: '#181c1e'
  on-surface-variant: '#43474e'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eef1f3'
  outline: '#74777f'
  outline-variant: '#c4c6cf'
  surface-tint: '#455f88'
  primary: '#002045'
  on-primary: '#ffffff'
  primary-container: '#1a365d'
  on-primary-container: '#86a0cd'
  inverse-primary: '#adc7f7'
  secondary: '#13696a'
  on-secondary: '#ffffff'
  secondary-container: '#a2eded'
  on-secondary-container: '#1a6d6e'
  tertiary: '#2d1d00'
  on-tertiary: '#ffffff'
  tertiary-container: '#493100'
  on-tertiary-container: '#cb9524'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d6e3ff'
  primary-fixed-dim: '#adc7f7'
  on-primary-fixed: '#001b3c'
  on-primary-fixed-variant: '#2d476f'
  secondary-fixed: '#a5eff0'
  secondary-fixed-dim: '#89d3d4'
  on-secondary-fixed: '#002020'
  on-secondary-fixed-variant: '#004f50'
  tertiary-fixed: '#ffdeaa'
  tertiary-fixed-dim: '#f8bc4b'
  on-tertiary-fixed: '#271900'
  on-tertiary-fixed-variant: '#5f4100'
  background: '#f7fafc'
  on-background: '#181c1e'
  surface-variant: '#e0e3e5'
typography:
  headline-xl:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-bold:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  button:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
  max-width: 1280px
---

## Brand & Style
The design system embodies the "Academic meets Wall Street" narrative—a sophisticated fusion of Ivy League prestige and modern financial precision. It is built to serve high-achieving candidates navigating the competitive landscapes of investment banking and management consulting. 

The aesthetic is **Corporate Modern with subtle Glassmorphic accents**. It prioritizes clarity and authority, using structured layouts that feel established, while incorporating soft translucent layers to maintain a sense of contemporary accessibility. The UI should evoke a feeling of "guaranteed trajectory": stable, elite, yet inclusive of the next generation of global leaders.

## Colors
This design system utilizes a traditional tripartite palette to balance authority with action.

- **Primary (Navy Success):** Used for global navigation, primary headings, and high-level structural elements to ground the brand in stability.
- **Secondary (Accessible Teal):** Used for mentorship-related features, progress indicators, and secondary interactive elements to signal growth and support.
- **Accent (Gold Opportunity):** Reserved exclusively for high-priority Call-to-Actions (CTAs) and success-state highlights.
- **Neutral (Slate Grays):** A range of cool grays (from #F7FAFC to #2D3748) provides the canvas, ensuring the "Academic" white-space remains crisp and legible.

## Typography
The typography strategy leverages the contrast between a transitional serif and a utilitarian sans-serif. 

**Playfair Display** is used for headlines to echo the mastheads of prestigious financial journals and the architectural lettering of elite universities. It should always be set with tighter letter-spacing in larger sizes.

**Inter** handles all functional text. It provides the "tech-forward" balance required for a digital platform, ensuring that complex career advice and financial data remain highly readable. Use medium and semi-bold weights for labels to maintain hierarchy without needing to increase font size.

## Layout & Spacing
The layout follows a **Fixed Grid** philosophy for desktop to maintain an "Editorial" feel, transitioning to a fluid model for mobile.

- **Desktop (1280px+):** A 12-column grid with 24px gutters. Content is centered with generous 64px side margins to create a sense of focus and prestige.
- **Tablet (768px - 1279px):** An 8-column grid with 24px gutters and 32px margins.
- **Mobile (<767px):** A 4-column fluid grid with 16px margins. 

Vertical rhythm is strictly maintained using 8px increments. Large sections of content should be separated by 80px - 120px of whitespace to allow the premium typography to "breathe."

## Elevation & Depth
This design system uses **Tonal Layers** combined with **Glassmorphism** to create hierarchy:

1.  **Base Layer:** Solid `#FFFFFF` or `#F7FAFC`.
2.  **Card Layer:** Semi-transparent white (#FFFFFF, 80% opacity) with a `20px` backdrop blur. This creates the "modern" feel while keeping the content legible.
3.  **Shadows:** Use extremely soft, long-range ambient shadows. 
    *   *Example:* `0 4px 20px rgba(26, 54, 93, 0.05)` — the shadow color is slightly tinted with the Primary Navy to ensure it feels integrated rather than "dirty."
4.  **Interactive States:** On hover, cards should increase in elevation slightly with a more pronounced shadow and a subtle Primary-colored border (1px).

## Shapes
The shape language is "Soft Professional." Elements use an **8px (Standard)** to **12px (Large)** corner radius. 

- **Buttons & Inputs:** 8px radius to maintain a crisp, business-like edge.
- **Cards & Modals:** 12px radius to soften the interface and make the glassmorphism feel more organic and approachable.
- **Iconography:** Use 24px bounding boxes with a 2px stroke weight. Icons should be "outlined" rather than "filled" to mirror the light, airy feel of the typography.

## Components
- **Buttons:** 
    - *Primary:* Gold (#D69E2E) background with white text. High contrast for critical actions (e.g., "Book Coaching").
    - *Secondary:* Navy (#1A365D) outline with navy text. Used for "Learn More" or "View Profile."
- **Glass Cards:** Feature a 1px border (#E2E8F0) and a subtle backdrop blur. These are used for "Firm Insights" or "Mentor Profiles."
- **Input Fields:** Use a light gray fill (#EDF2F7) that transitions to a white background with a Navy border on focus. Labels sit 4px above the field in `label-bold`.
- **Chips/Badges:** Used for firm categories (e.g., "MBB," "Bulge Bracket"). These should have a Teal (#2C7A7B) background at 10% opacity with solid Teal text.
- **Progress Indicators:** High-contrast Teal bars to track application or course completion, providing a visual "growth" cue.
- **Imagery:** All photos should have a slight cool-toned overlay or desaturation to ensure they sit harmoniously behind Navy or White text.